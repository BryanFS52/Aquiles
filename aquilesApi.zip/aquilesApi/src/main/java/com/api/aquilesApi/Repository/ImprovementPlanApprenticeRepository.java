package com.api.aquilesApi.Repository;

import com.api.aquilesApi.Entity.ImprovementPlanApprentice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ImprovementPlanApprenticeRepository extends JpaRepository<ImprovementPlanApprentice, Long> {
}
