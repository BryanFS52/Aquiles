package com.api.aquilesApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ImprovementPlanApprenticeDto {
    private Long id;
    private Long improvementPlanId;
    private String name;
    private String lastname;
    private String email;
    private String document;
}
