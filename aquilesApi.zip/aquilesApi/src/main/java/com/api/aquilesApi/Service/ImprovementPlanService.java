package com.api.aquilesApi.Service;

import com.api.aquilesApi.Entity.ImprovementPlan;
import com.api.aquilesApi.Repository.ImprovementPlanRepository;
import com.api.aquilesApi.Service.Dao.Idao; // Asegúrate de que Idao esté correcto
import com.api.aquilesApi.Utilities.CustomException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest; // Importar PageRequest si se usa
import org.springframework.data.domain.Pageable; // Para el método findAll original
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ImprovementPlanService implements Idao<ImprovementPlan, Long> {
    private final ImprovementPlanRepository improvementPlanRepository;

    public ImprovementPlanService(ImprovementPlanRepository improvementPlanRepository) {
        this.improvementPlanRepository = improvementPlanRepository;
    }

    // Nuevo método: existe plan activo para un aprendiz
    public boolean existsActivePlanForLearner(Long learnerId) {
        // Asegúrate de que tu ImprovementPlanRepository tenga un método llamado existsByLearnerIdAndStateTrue
        return improvementPlanRepository.existsByLearnerIdAndStateTrue(learnerId);
    }

    @Override
    public Page<ImprovementPlan> findAll(PageRequest pageRequest) {
        return improvementPlanRepository.findAll(pageRequest);
    }

    // Si tu Idao define findAll con Pageable, asegúrate de tener este también
    public Page<ImprovementPlan> findAll(Pageable pageable) {
        return improvementPlanRepository.findAll(pageable);
    }

    @Override
    public ImprovementPlan getById(Long id) {
        return improvementPlanRepository.findById(id).orElseThrow(() ->
                new CustomException("Attendance Type with id " + id + " not found", HttpStatus.NO_CONTENT));
    }

    @Override
    public void update(ImprovementPlan entity) {
        this.improvementPlanRepository.save(entity);
    }

    @Override
    public ImprovementPlan save(ImprovementPlan entity) {
        return improvementPlanRepository.save(entity);
    }

    @Override
    public void delete(ImprovementPlan entity) {
        this.improvementPlanRepository.delete(entity);
    }

    @Override
    public void create(ImprovementPlan entity) {
        this.improvementPlanRepository.save(entity);
    }
}

