package com.api.aquilesApi.Business;

import com.api.aquilesApi.Dto.ImprovementPlanApprenticeDto;
import com.api.aquilesApi.Entity.ImprovementPlanApprentice;
import com.api.aquilesApi.Service.ImprovementPlanApprenticeService;
import com.api.aquilesApi.Utilities.CustomException;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class ImprovementPlanApprenticeBusiness {

    private final ImprovementPlanApprenticeService service;

    public ImprovementPlanApprenticeBusiness(ImprovementPlanApprenticeService service) {
        this.service = service;
    }

    /**
     * findAll con paginación. Si page o size vienen null, values por defecto: page=0 size=10
     */
    public Page<ImprovementPlanApprenticeDto> findAll(Integer page, Integer size) {
        try {
            int p = (page == null || page < 0) ? 0 : page;
            int s = (size == null || size <= 0) ? 10 : size; // default 10 por página
            Page<ImprovementPlanApprentice> pageResult = service.findAll(PageRequest.of(p, s));
            return pageResult.map(service::toDto);
        } catch (DataAccessException e) {
            throw new CustomException("Error retrieving ImprovementPlanApprentice: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ImprovementPlanApprenticeDto findById(Long id) {
        try {
            return service.findDtoById(id);
        } catch (CustomException e) {
            throw e;
        } catch (Exception e) {
            throw new CustomException("Error getting ImprovementPlanApprentice: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    public ImprovementPlanApprenticeDto add(ImprovementPlanApprenticeDto dto) {
        try {
            // valida que venga improvementPlanId para crear
            var saved = service.saveFromDto(dto);
            return service.toDto(saved);
        } catch (CustomException e) {
            throw e;
        } catch (Exception e) {
            throw new CustomException("Error adding ImprovementPlanApprentice: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    public void update(Long id, ImprovementPlanApprenticeDto dto) {
        try {
            dto.setId(id);
            service.saveFromDto(dto);
        } catch (CustomException e) {
            throw e;
        } catch (Exception e) {
            throw new CustomException("Error updating ImprovementPlanApprentice: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    public void delete(Long id) {
        try {
            ImprovementPlanApprentice entity = service.getById(id);
            service.delete(entity);
        } catch (CustomException e) {
            throw e;
        } catch (Exception e) {
            throw new CustomException("Error deleting ImprovementPlanApprentice: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
