package com.api.aquilesApi.Dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImprovementPlanFaultTypeDto {
    private Long id;

    @NotBlank(message = "The name is required")
    private String name;
}
