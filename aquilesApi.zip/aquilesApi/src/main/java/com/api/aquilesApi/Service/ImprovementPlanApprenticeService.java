package com.api.aquilesApi.Service;

import com.api.aquilesApi.Dto.ImprovementPlanApprenticeDto;
import com.api.aquilesApi.Entity.ImprovementPlan;
import com.api.aquilesApi.Entity.ImprovementPlanApprentice;
import com.api.aquilesApi.Repository.ImprovementPlanApprenticeRepository;
import com.api.aquilesApi.Repository.ImprovementPlanRepository;
import com.api.aquilesApi.Service.Dao.Idao;
import com.api.aquilesApi.Utilities.CustomException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class ImprovementPlanApprenticeService implements Idao<ImprovementPlanApprentice, Long> {

    private final ImprovementPlanApprenticeRepository repository;
    private final ImprovementPlanRepository improvementPlanRepository;

    public ImprovementPlanApprenticeService(ImprovementPlanApprenticeRepository repository,
                                            ImprovementPlanRepository improvementPlanRepository) {
        this.repository = repository;
        this.improvementPlanRepository = improvementPlanRepository;
    }

    @Override
    public Page<ImprovementPlanApprentice> findAll(PageRequest pageRequest) {
        return repository.findAll(pageRequest);
    }

    @Override
    public ImprovementPlanApprentice getById(Long id) {
        return repository.findById(id).orElseThrow(() ->
                new CustomException("Improvement Plan Apprentice with id " + id + " not found", HttpStatus.NO_CONTENT));
    }

    @Override
    public void update(ImprovementPlanApprentice entity) {
        repository.save(entity);
    }

    @Override
    public ImprovementPlanApprentice save(ImprovementPlanApprentice entity) {
        return repository.save(entity);
    }

    @Override
    public void delete(ImprovementPlanApprentice entity) {
        repository.delete(entity);
    }

    @Override
    public void create(ImprovementPlanApprentice entity) {
        repository.save(entity);
    }

    public ImprovementPlanApprenticeDto toDto(ImprovementPlanApprentice e) {
        Long planId = e.getImprovementPlan() != null ? e.getImprovementPlan().getId() : null;
        return new ImprovementPlanApprenticeDto(
                e.getId(),
                planId,
                e.getName(),
                e.getLastname(),
                e.getEmail(),
                e.getDocument()
        );
    }

    public ImprovementPlanApprentice saveFromDto(ImprovementPlanApprenticeDto dto) {
        try {
            ImprovementPlanApprentice entity;

            if (dto.getId() != null && repository.existsById(dto.getId())) {
                entity = repository.findById(dto.getId()).get();
            } else {
                entity = new ImprovementPlanApprentice();
            }

            // Asignar ImprovementPlan
            if (dto.getImprovementPlanId() != null) {
                ImprovementPlan plan = improvementPlanRepository.findById(dto.getImprovementPlanId())
                        .orElseThrow(() -> new CustomException("ImprovementPlan not found with id " + dto.getImprovementPlanId(), HttpStatus.BAD_REQUEST));
                entity.setImprovementPlan(plan);
            } else if (entity.getImprovementPlan() == null) {
                throw new CustomException("improvementPlanId is required to create ImprovementPlanApprentice", HttpStatus.BAD_REQUEST);
            }

            // Asignar campos
            entity.setName(dto.getName());
            entity.setLastname(dto.getLastname());
            entity.setEmail(dto.getEmail());
            entity.setDocument(dto.getDocument());

            return repository.save(entity);
        } catch (CustomException ce) {
            throw ce;
        } catch (Exception e) {
            throw new CustomException("Error saving ImprovementPlanApprentice: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ImprovementPlanApprenticeDto findDtoById(Long id) {
        return toDto(getById(id));
    }
}
