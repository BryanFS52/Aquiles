package com.api.aquilesApi.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.io.Serializable;

@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "improvement_plan_apprentices")
public class ImprovementPlanApprentice implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "improvement_plan_id", nullable = false)
    private ImprovementPlan improvementPlan;

    @Column(name = "name", length = 55, nullable = false)
    private String name;

    @Column(name = "lastname", length = 55, nullable = false)
    private String lastname;

    @Column(name = "email", length = 55, nullable = false)
    private String email;

    @Column(name = "document",length = 15, nullable = false)
    private String document;
}

