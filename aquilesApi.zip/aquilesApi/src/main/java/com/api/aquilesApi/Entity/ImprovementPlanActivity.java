package com.api.aquilesApi.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "ImprovementPlan_activities")
public class ImprovementPlanActivity implements Serializable {

    @Transient
    private final SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "improvement_plan_id", nullable = false)
    private ImprovementPlan improvementPlan;

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "delivery_date", nullable = false)
    private Date deliveryDate;

    @Column(name = "delivery_format", nullable = false)
    private String deliveryFormat;

    @Column(name = "learning_outcome", nullable = false)
    private String learningOutcome;

    public void setDeliveryDate(String deliveryDate) throws ParseException {
        this.deliveryDate = dateTimeFormatter.parse(deliveryDate);
    }

    public String getDeliveryDate() {
        return (deliveryDate != null) ? dateTimeFormatter.format(deliveryDate) : null;
    }
}