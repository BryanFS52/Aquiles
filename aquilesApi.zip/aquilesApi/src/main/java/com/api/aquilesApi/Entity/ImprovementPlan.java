    package com.api.aquilesApi.Entity;

    import jakarta.persistence.*;
    import lombok.Getter;
    import lombok.NoArgsConstructor;
    import lombok.Setter;
    import java.io.Serializable;
    import java.util.Date;
    import java.util.List;

    @NoArgsConstructor
    @Getter
    @Setter
    @Entity
    @Table(name = "improvement_plan")
    public class ImprovementPlan implements Serializable {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(name = "city", nullable = false, length = 55)
        private String city;

        @Column(name = "date", nullable = false)
        private Date date;

        @Column(name = "reason", nullable = false, length = 255)
        private String reason;

        @Column(name = "number", nullable = false)
        private Integer number;

        @Column(name = "state", nullable = false)
        private Boolean state;

        private Long studentId;

        @OneToOne(mappedBy = "improvementPlan", cascade = CascadeType.ALL, orphanRemoval = true)
        private Notifications notification;

        @OneToMany(mappedBy = "improvementPlan", cascade = CascadeType.ALL, orphanRemoval = true)
        private List<ImprovementPlanActivity> activities;

        @OneToOne(mappedBy = "improvementPlan", cascade = CascadeType.ALL, orphanRemoval = true)
        private ImprovementPlanApprentice apprentice;

        @OneToMany(mappedBy = "improvementPlan", cascade = CascadeType.ALL, orphanRemoval = true)
        private List<ImprovementPlanEvidenceType> evidenceTypes;

        @OneToMany(mappedBy = "improvementPlan", cascade = CascadeType.ALL, orphanRemoval = true)
        private List<ImprovementPlanFaultType> faultTypes;
    }
