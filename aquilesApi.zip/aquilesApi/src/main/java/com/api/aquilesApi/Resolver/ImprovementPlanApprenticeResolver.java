package com.api.aquilesApi.Resolver;

import com.api.aquilesApi.Business.ImprovementPlanApprenticeBusiness;
import com.api.aquilesApi.Dto.ImprovementPlanApprenticeDto;
import com.api.aquilesApi.Utilities.Http.ResponseHttpApi;
import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsQuery;
import com.netflix.graphql.dgs.InputArgument;
import com.netflix.graphql.dgs.DgsMutation;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;

import java.util.Map;

@DgsComponent
public class ImprovementPlanApprenticeResolver {
    private final ImprovementPlanApprenticeBusiness business;

    public ImprovementPlanApprenticeResolver(ImprovementPlanApprenticeBusiness business) {
        this.business = business;
    }

    @DgsQuery
    public Map<String, Object> allImprovementPlanApprentices(@InputArgument Integer page, @InputArgument Integer size) {
        try {
            Page<ImprovementPlanApprenticeDto> pageResult = business.findAll(page, size);
            return ResponseHttpApi.responseHttpFindAll(
                    pageResult.getContent(),
                    ResponseHttpApi.CODE_OK,
                    "Query ok",
                    pageResult.getTotalPages(),
                    page,
                    (int) pageResult.getTotalElements()
            );
        } catch (Exception e) {
            return ResponseHttpApi.responseHttpError(
                    "Error retrieving ImprovementPlanApprentices: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @DgsQuery
    public Map<String, Object> improvementPlanApprenticeById(@InputArgument Long id) {
        try {
            ImprovementPlanApprenticeDto dto = business.findById(id);
            return ResponseHttpApi.responseHttpFindId(dto, ResponseHttpApi.CODE_OK, "Query by id ok");
        } catch (Exception e) {
            return ResponseHttpApi.responseHttpError(
                    "Error retrieving ImprovementPlanApprentice: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @DgsMutation
    public Map<String, Object> addImprovementPlanApprentice(@InputArgument(name = "input") ImprovementPlanApprenticeDto dto) {
        try {
            ImprovementPlanApprenticeDto saved = business.add(dto);
            return ResponseHttpApi.responseHttpAction(saved.getId(), ResponseHttpApi.CODE_OK, "Add ok");
        } catch (Exception e) {
            return ResponseHttpApi.responseHttpError(
                    "Error adding ImprovementPlanApprentice: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @DgsMutation
    public Map<String, Object> updateImprovementPlanApprentice(@InputArgument Long id, @InputArgument(name = "input") ImprovementPlanApprenticeDto dto) {
        try {
            business.update(id, dto);
            return ResponseHttpApi.responseHttpAction(id, ResponseHttpApi.CODE_OK, "Update ok");
        } catch (Exception e) {
            return ResponseHttpApi.responseHttpError(
                    "Error updating ImprovementPlanApprentice: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    @DgsMutation
    public Map<String, Object> deleteImprovementPlanApprentice(@InputArgument Long id) {
        try {
            business.delete(id);
            return ResponseHttpApi.responseHttpAction(id, ResponseHttpApi.CODE_OK, "Delete ok");
        } catch (Exception e) {
            return ResponseHttpApi.responseHttpError(
                    "Error deleting ImprovementPlanApprentice: " + e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }
}
