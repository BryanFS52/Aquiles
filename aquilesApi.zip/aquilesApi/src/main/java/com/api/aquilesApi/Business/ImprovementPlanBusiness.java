package com.api.aquilesApi.Business;

import com.api.aquilesApi.Dto.ImprovementPlanDto;
import com.api.aquilesApi.Entity.ImprovementPlan;
import com.api.aquilesApi.Service.ImprovementPlanService;
import com.api.aquilesApi.Utilities.CustomException;
import org.modelmapper.ModelMapper;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@Component
public class ImprovementPlanBusiness {

    private final ImprovementPlanService improvementPlanService;
    private final ModelMapper modelMapper;

    public ImprovementPlanBusiness(ImprovementPlanService improvementPlanService, ModelMapper modelMapper) {
        this.improvementPlanService = improvementPlanService;
        this.modelMapper = modelMapper;
    }

    // Validate date and duplicate active plan
    private void validateImprovementPlan(ImprovementPlanDto dto) {
        // Check if deadline date is before today
        try {
            LocalDate planDate = LocalDate.parse(dto.getDate());
            if (planDate.isBefore(LocalDate.now())) {
                throw new CustomException(
                        "Deadline date cannot be earlier than today.",
                        HttpStatus.BAD_REQUEST
                );
            }
        } catch (DateTimeParseException e) {
            throw new CustomException("Invalid date format. Use YYYY-MM-DD.", HttpStatus.BAD_REQUEST);
        }

        // Check for active plan for same learner
        boolean hasActivePlan = improvementPlanService.existsActivePlanForLearner(
                dto.getLearnerId()
        );

        if (hasActivePlan) {
            throw new CustomException(
                    "An active improvement plan already exists for this learner. A new plan cannot be created without justification.",
                    HttpStatus.CONFLICT
            );
        }
    }

    // Find all plans
    public Page<ImprovementPlanDto> findAll(int page, int size) {
        try {
            PageRequest pageRequest = PageRequest.of(page, size);
            Page<ImprovementPlan> improvementPlanPage = improvementPlanService.findAll(pageRequest);
            return improvementPlanPage.map(entity -> modelMapper.map(entity, ImprovementPlanDto.class));
        } catch (DataAccessException e) {
            throw new CustomException("Error retrieving improvement plans: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            throw new CustomException("Unexpected error retrieving improvement plans.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Find by ID
    public ImprovementPlanDto findById(Long id) {
        try {
            ImprovementPlan improvementPlan = improvementPlanService.getById(id);
            return modelMapper.map(improvementPlan, ImprovementPlanDto.class);
        } catch (CustomException e) {
            throw e;
        } catch (Exception e) {
            throw new CustomException("Error getting the plan: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Add plan
    public ImprovementPlanDto add(ImprovementPlanDto improvementPlanDto) {
        try {
            validateImprovementPlan(improvementPlanDto);
            ImprovementPlan improvementPlan = modelMapper.map(improvementPlanDto, ImprovementPlan.class);
            return modelMapper.map(improvementPlanService.save(improvementPlan), ImprovementPlanDto.class);
        } catch (Exception e) {
            throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Update plan
    public void update(Long id, ImprovementPlanDto improvementPlanDto) {
        try {
            improvementPlanDto.setId(id);
            validateImprovementPlan(improvementPlanDto);
            ImprovementPlan improvementPlan = modelMapper.map(improvementPlanDto, ImprovementPlan.class);
            improvementPlanService.save(improvementPlan);
        } catch (Exception e) {
            throw new CustomException("Error updating the plan: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Delete plan
    public void delete(Long id) {
        try {
            ImprovementPlan improvementPlan = improvementPlanService.getById(id);
            improvementPlanService.delete(improvementPlan);
        } catch (CustomException e) {
            throw e;
        } catch (Exception e) {
            throw new CustomException("Error deleting the plan: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
