package com.api.aquilesApi.Dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImprovementPlanActivityDto {
    private Long id;

    @NotNull(message = "The Improvement Plan ID is required")
    private Long improvementPlanId;

    @NotBlank(message = "The description is required")
    private String description;

    @NotNull(message = "The delivery date is required")
    private String deliveryDate;

    @NotBlank(message = "The delivery format is required")
    private String deliveryFormat;

    @NotBlank(message = "The learning outcome is required")
    private String learningOutcome;
}
